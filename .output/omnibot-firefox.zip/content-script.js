(() => {
  // src/content-script.ts
  console.log("[OrderFlow Extension] Content script loaded on web.whatsapp.com");
  function mountSidePanel() {
    if (document.getElementById("orderflow-wa-root")) return;
    const root = document.createElement("div");
    root.id = "orderflow-wa-root";
    root.style.position = "fixed";
    root.style.right = "0";
    root.style.top = "0";
    root.style.height = "100vh";
    root.style.zIndex = "999999";
    root.style.display = "flex";
    const shadow = root.attachShadow({ mode: "open" });
    const container = document.createElement("div");
    container.id = "orderflow-container";
    shadow.appendChild(container);
    document.body.appendChild(root);
    console.log("[OrderFlow Extension] Embedded side panel mounted into Shadow DOM");
  }
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mountSidePanel);
  } else {
    mountSidePanel();
  }
})();
