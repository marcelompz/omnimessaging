(() => {
  // src/background.ts
  console.log("[OrderFlow Extension] Background worker initialized");
})();
